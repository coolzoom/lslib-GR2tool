﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Gppg")]
[assembly: AssemblyDescription("Gardens Point Parser Generator version 1.5.2 (2014-08-23)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("QUT")]
[assembly: AssemblyProduct("Gppg")]
[assembly: AssemblyCopyright("Copyright © Wayne Kelly, John Gough 2005-2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("6b5106e4-43bb-4a39-93df-9cc12f311d4f")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.5.2")]
[assembly: AssemblyFileVersion("1.5.2")]
